"""
Phoenix Grid Trading System v3.1 (CUSTOM)
SOXL 자동매매 시스템 - Tier 1 거래 기능 포함
"""

__version__ = "3.1.0-custom"
__author__ = "Phoenix Trading System"
